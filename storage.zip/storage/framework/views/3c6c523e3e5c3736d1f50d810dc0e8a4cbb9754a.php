<?php $__env->startSection('content'); ?>
<br /> <br />
    <!--== Login Page Content Start ==-->
    <section id="lgoin-page-wrap" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-8 m-auto">
                	<div class="login-page-content">
                		<div class="login-form">
                			<h3>Bienvenue !</h3>
							<form method="POST" action="<?php echo e(route('login')); ?>">
                       			 <?php echo csrf_field(); ?>
								<div class="username">
									<input id="email" type="email"
                                 class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                  name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email"
                                   autofocus>
									<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
								<div class="password">
									<input id="password" type="password"
                                 class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                  name="password" required autocomplete="current-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>

								<div class="log-btn">
									<button type="submit"><i class="fa fa-sign-in"></i> Connexion</button>
								</div>
							</form>
                		</div>
                		
                		<div class="login-other">
                			<span class="or">ou</span>
                			<a href="<?php echo e(url('/redirect_facebook')); ?>" class="login-with-btn facebook">
							<i class="fa fa-facebook"></i> Connexion avec Facebook</a>
                			<a href="<?php echo e(url('/redirect_google')); ?>" class="login-with-btn google">
							<i class="fa fa-google"></i> Connexion avec Google</a>
                		</div>
                		
                		
                	</div>
                </div>
        	</div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon1\www\makamer\resources\views/auth/login.blade.php ENDPATH**/ ?>