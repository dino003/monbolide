<?php $__env->startSection('content'); ?>
      <!--== Slider Area Start ==-->
      <section id="slider-area">
        <!--== slide Item One ==-->
        <div class="single-slide-item overlay">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5" id="form_demande_vehicule_apprentissage">
                  
                    </div>

                    <div class="col-lg-7 text-right">
                        <div class="display-table">
                            <div class="display-table-cell">
                                <div class="slider-right-text">
                                <h1>RESERVEZ UNE VOITURE AUJOURD'HUI !</h1>
                                    <p>A PARTIR DE 15000 FCFA</p> <br />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--== slide Item One ==-->
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon1\www\makamer\resources\views/reser.blade.php ENDPATH**/ ?>