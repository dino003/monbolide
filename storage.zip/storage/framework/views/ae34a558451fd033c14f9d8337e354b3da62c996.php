<header id="header-area" class="fixed-top">
        <!--== Header Top Start ==-->
        <div id="header-top" class="d-none d-xl-block">
            <div class="container">
                <div class="row">
               
                    <!--== Single HeaderTop Start ==-->
                    <div class="col-lg-3 text-left">
                    <i class="fa fa-map-marker"></i> 802/2, CI, Abidjan
                    </div>
                    <!--== Single HeaderTop End ==-->

                    <!--== Single HeaderTop Start ==-->
                    <div class="col-lg-3 text-center">
                    <i class="fa fa-mobile"></i> +225 89 85 12 24 / 59 85 10 67
                    </div>
                    <!--== Single HeaderTop End ==-->

                    <!--== Single HeaderTop Start ==-->
                    <div class="col-lg-3 text-center">
                    <i class="fa fa-clock-o"></i> Lun-Ven 09h00 - 17h00
                    </div>
                    <!--== Single HeaderTop End ==-->

                    <!--== Social Icons Start ==-->
                    <div class="col-lg-3 text-right">
                        <div class="header-social-icons">
                            <a href="#"><i class="fa fa-behance"></i></a>
                            <a href="#"><i class="fa fa-pinterest"></i></a>
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-linkedin"></i></a>
                        </div>
                    </div>
                    <!--== Social Icons End ==-->
                </div>
            </div>
        </div>
        <!--== Header Top End ==-->

        <!--== Header Bottom Start ==-->
        <div id="header-bottom">
            <div class="container">
                <div class="row">
                    <!--== Logo Start ==-->
                    <div class="col-lg-4">
                        <a href="index2.html" class="logo">
                        <img src="<?php echo e(asset('assets/img/boli.png')); ?>" alt="JSOFT" />
                        </a>
                    </div>
                    <!--== Logo End ==-->

                    <!--== Main Menu Start ==-->
                    <div class="col-lg-8 d-none d-xl-block">
                    <?php if(Session::has('message')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>">
                <?php echo e(Session::get('message')); ?></p>
                <?php endif; ?>

                        <nav class="mainmenu alignright">
                            <ul>
                            <li className="active"><a href="<?php echo e(url('/')); ?>">Acceuil</a>

                               <!-- <li><a href="about.html">About</a></li> -->
                                <li><a href="services.html">services</a>
                                <ul>
                                        <li><a href="<?php echo e(url('/reservation_de_vehicule')); ?>">Demande véhicule pour apprentissage</a></li>
                                        
                                       
                                    </ul>
                                </li>
                             
                               
                               
                                <li><a href="#">Contact</a></li>
                                <?php if(auth()->guard()->guest()): ?>

                                <li><a href="#">Compte</a>
                                <ul>
                            <li>
                                <a href="<?php echo e(route('login')); ?>"><?php echo e(__('Connexion')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li>
                                    <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Inscription')); ?></a>
                                </li>
                            <?php endif; ?>
                            </ul>
                            </li>
                            
                        <?php else: ?>
                        <li >
                                <a  href="#" >
                                    <?php echo e(substr(Auth::user()->name, 0, 12)); ?> 
                                </a>

                                <ul >
                                <?php if(Auth::user()->isAdmin): ?>
                                <li>
                                    <a href="<?php echo e(url('/v1/admin_area/dashboard')); ?>"><?php echo e(__('Admin panel')); ?></a>
                                </li>
                                <?php endif; ?>
                                   <li>
                                    <a  href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Déconnexion')); ?>

                                    </a>
                                    </li>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </ul>
                            </li>
                        <?php endif; ?>
                                
                            
                            </ul>
                        </nav>
                    </div>
                    <!--== Main Menu End ==-->
                </div>
            </div>
        </div>
        <!--== Header Bottom End ==-->
    </header><?php /**PATH C:\laragon1\www\makamer\resources\views/layouts/nav.blade.php ENDPATH**/ ?>