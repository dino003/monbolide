<?php $__env->startSection('content'); ?>

      <!--== Login Page Content Start ==-->
      <section id="lgoin-page-wrap" class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-8 m-auto">
                	<div class="login-page-content">
                		<div class="login-form">
                			<h3>Inscription</h3>
							<form method="POST" action="<?php echo e(route('register')); ?>">
                       			 <?php echo csrf_field(); ?>							
								<div class="username">
	
									  <input id="name" type="text"
                                 class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                  name="name" placeholder="Votre Nom" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>
								<div class="username">
									<input id="email"
									placeholder="Adresse email"
									 type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
									  name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

									<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($message); ?></strong>
										</span>
									<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                                 

								</div>
								<div class="password">
									<input id="password"
									placeholder="Mot de passe"
									 type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

										<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
										<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
								</div>

								<div class="password">
								<input id="password-confirm"
								 type="password" class="form-control"
								 placeholder="confirmation"
								  name="password_confirmation" required autocomplete="new-password">
									
								</div>
								<div class="log-btn">
									<button type="submit"><i class="fa fa-check-square"></i> Enregistrer</button>
								</div>
							</form>
                		</div>
                		
                		<div class="login-other">
                			<span class="or">Inscription rapide</span>
                			<a href="#" class="login-with-btn facebook"><i class="fa fa-facebook"></i> Inscription via Facebook</a>
                			<a href="#" class="login-with-btn google"><i class="fa fa-google"></i> Inscription via Google</a>
                		</div>
                		<div class="create-ac">
                			<p>Vous avez deja un compte ? <a href="<?php echo e(route('login')); ?>">Connectez-vous</a></p>
                		</div>
         
                	</div>
                </div>
        	</div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon1\www\makamer\resources\views/auth/register.blade.php ENDPATH**/ ?>